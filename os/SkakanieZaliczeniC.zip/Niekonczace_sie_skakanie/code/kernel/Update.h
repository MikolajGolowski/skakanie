
#ifndef NIEKONCZACE_SIE_SKAKANIE_UPDATE_H
#define NIEKONCZACE_SIE_SKAKANIE_UPDATE_H
#include "Engine.h"
#include <time.h>
#include "SDL.h"
#include "SDL_image.h"
#include "../rendering/Tekstury.h"
#include "../mapa/Mapa.h"
//#include <math.h>

short Update(gra_t* gra, clock_t uplyw);


#endif //NIEKONCZACE_SIE_SKAKANIE_UPDATE_H
