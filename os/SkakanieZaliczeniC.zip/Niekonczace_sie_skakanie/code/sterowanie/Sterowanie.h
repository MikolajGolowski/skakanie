#ifndef NIEKONCZACE_SIE_SKAKANIE_STEROWANIE_H
#define NIEKONCZACE_SIE_SKAKANIE_STEROWANIE_H
#include "../kernel/Engine.h"
#include "../savegame/save.h"

short InputZKlawiatury(gra_t* gra);

#endif //NIEKONCZACE_SIE_SKAKANIE_STEROWANIE_H
